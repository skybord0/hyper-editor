# Installation

1. Install Python 3.11+.
2. Open a terminal in the HYPER_EDITOR folder.
3. Run `python -m pip install -r requirements.txt`.
4. Start with `python app.py`.
5. Open `http://127.0.0.1:5000`.

For OCR, install Tesseract separately and ensure its executable is available to pytesseract.
