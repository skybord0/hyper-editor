# PDF Studio Features

The PDF Studio workspace supports:

- page thumbnails and navigation
- zoom
- existing text span selection
- text replacement with approximate original font, colour, size and position
- text box position and size editing
- add text
- highlight, underline, strikeout and redact
- rectangle, ellipse and line drawing
- freehand drawing
- image insertion
- typed signature placement
- OCR extraction pathway
- rotate, delete, duplicate and add blank pages
- reorder pages
- undo and redo
- save edited PDF

Scanned/image-only PDFs need OCR for text editing. OCR availability depends on the local Tesseract installation used by pytesseract.
