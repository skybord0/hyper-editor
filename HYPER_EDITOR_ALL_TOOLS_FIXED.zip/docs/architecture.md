# HYPER EDITOR Architecture

Flask application shell with service-oriented conversion logic.

- `routes/` contains HTTP APIs and page routes.
- `services/` contains upload, conversion, history, PDF Studio and Word Studio logic.
- `converters/` contains individual format conversion engines.
- `templates/` contains the modern web UI.
- `static/` contains UI CSS and editor JavaScript.
- `uploads/`, `outputs/`, `instance/` and `logs/` are runtime directories.

PDF editing uses PyMuPDF for page rendering, text span extraction, redaction/replacement, annotations, graphics, page operations, image insertion and document export.
