# Conversion Matrix

| Input | Supported actions |
|---|---|
| PNG/JPG/JPEG/WEBP | image conversion, Images → PDF, Images → Word |
| PDF | JPG, PNG, TXT, Word, merge, split, compress, edit, rotate, delete, extract, reorder, page numbers, watermark, image extraction |
| DOCX | TXT, PDF, JPG, PNG, Edit Word |
| XLSX | CSV, PDF |
| CSV | XLSX |
| PPTX | PDF, JPG, PNG |
| TXT | PDF, Word |
| HTML/HTM | PDF |
| ZIP | Extract |
