Runtime files are stored in uploads/, outputs/, logs/ and instance/ and are intentionally excluded from the distributed ZIP.
