import os, shutil, subprocess

def _libreoffice_convert(input_path, output_path):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return False
    outdir=os.path.dirname(os.path.abspath(output_path)); os.makedirs(outdir,exist_ok=True)
    p=subprocess.run([soffice,"--headless","--convert-to","pdf","--outdir",outdir,input_path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
    produced=os.path.join(outdir,os.path.splitext(os.path.basename(input_path))[0]+".pdf")
    if p.returncode==0 and os.path.exists(produced):
        if os.path.abspath(produced)!=os.path.abspath(output_path):
            if os.path.exists(output_path): os.remove(output_path)
            os.replace(produced,output_path)
        return True
    return False

def convert_docx_to_pdf(input_path,output_path):
    # Use the Office-compatible renderer whenever available. This preserves page
    # layout, fonts, tables, margins and pagination far better than manual drawing.
    if _libreoffice_convert(input_path,output_path):
        return output_path
    from docx import Document
    from reportlab.pdfgen.canvas import Canvas
    from reportlab.lib.pagesizes import A4
    doc=Document(input_path);c=Canvas(output_path,pagesize=A4);w,h=A4;y=h-48
    for p in doc.paragraphs:
        if y<45:c.showPage();y=h-48
        text=p.text
        if text:
            c.setFont('Helvetica-Bold' if any(r.bold for r in p.runs) else 'Helvetica',10)
            c.drawString(42,y,text[:300])
        y-=14
    c.save();return output_path
