from docx import Document

def convert_docx_to_txt(input_path,output_path):
    doc=Document(input_path);lines=[p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:lines.append('\t'.join(c.text for c in row.cells))
    with open(output_path,'w',encoding='utf-8') as f:f.write('\n'.join(lines))
    return output_path
