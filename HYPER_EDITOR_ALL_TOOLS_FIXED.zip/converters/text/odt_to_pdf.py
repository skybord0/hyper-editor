import os,shutil,subprocess
def odt_to_pdf(input_path,output_path):
    exe=shutil.which('soffice') or shutil.which('libreoffice')
    if not exe: raise RuntimeError('ODT to PDF requires LibreOffice.')
    outdir=os.path.dirname(os.path.abspath(output_path)); os.makedirs(outdir,exist_ok=True)
    p=subprocess.run([exe,'--headless','--convert-to','pdf','--outdir',outdir,input_path],capture_output=True,text=True,timeout=180)
    produced=os.path.join(outdir,os.path.splitext(os.path.basename(input_path))[0]+'.pdf')
    if p.returncode!=0 or not os.path.exists(produced): raise RuntimeError(p.stderr or p.stdout or 'ODT to PDF failed.')
    if os.path.abspath(produced)!=os.path.abspath(output_path):
        if os.path.exists(output_path): os.remove(output_path)
        os.replace(produced,output_path)
    return output_path
