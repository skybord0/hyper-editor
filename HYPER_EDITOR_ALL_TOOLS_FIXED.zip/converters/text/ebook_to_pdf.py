import os,shutil,subprocess,zipfile,html as htmlmod

def _calibre(input_path, output_path):
    exe=shutil.which('ebook-convert')
    if not exe:return False
    p=subprocess.run([exe,input_path,output_path],capture_output=True,text=True,timeout=180)
    if p.returncode==0 and os.path.exists(output_path):return True
    raise RuntimeError(p.stderr or p.stdout or 'Calibre conversion failed.')

def ebook_to_pdf(input_path, output_path):
    if _calibre(input_path,output_path): return output_path
    ext=os.path.splitext(input_path)[1].lower()
    if ext!='.epub': raise RuntimeError('MOBI to PDF requires Calibre (ebook-convert).')
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.pagesizes import A4
    from bs4 import BeautifulSoup
    styles=getSampleStyleSheet(); story=[]
    with zipfile.ZipFile(input_path) as z:
        names=[n for n in z.namelist() if n.lower().endswith(('.xhtml','.html','.htm'))]
        for n in names:
            soup=BeautifulSoup(z.read(n),'html.parser')
            for p in soup.find_all(['h1','h2','h3','p','li']):
                text=' '.join(p.get_text(' ',strip=True).split())
                if text: story.append(Paragraph(htmlmod.escape(text),styles['Heading2' if p.name.startswith('h') else 'BodyText'])); story.append(Spacer(1,6))
    if not story: raise RuntimeError('No readable EPUB content found.')
    os.makedirs(os.path.dirname(output_path),exist_ok=True); SimpleDocTemplate(output_path,pagesize=A4).build(story); return output_path

def epub_to_mobi(input_path,output_path):
    if _calibre(input_path,output_path): return output_path
    raise RuntimeError('EPUB to MOBI requires Calibre. Install Calibre and make ebook-convert available in PATH.')

def mobi_to_pdf(input_path,output_path):
    if _calibre(input_path,output_path): return output_path
    raise RuntimeError('MOBI to PDF requires Calibre. Install Calibre and make ebook-convert available in PATH.')
