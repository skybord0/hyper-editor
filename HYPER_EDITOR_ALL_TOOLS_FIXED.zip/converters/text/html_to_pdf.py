from bs4 import BeautifulSoup
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A4
def html_to_pdf(input_path,output_path):
    soup=BeautifulSoup(open(input_path,encoding='utf-8',errors='replace').read(),'html.parser');c=Canvas(output_path,pagesize=A4);w,h=A4;y=h-45;c.setFont('Helvetica',10)
    for line in soup.get_text('\n').splitlines():
        line=line.strip()
        if not line:continue
        if y<40:c.showPage();c.setFont('Helvetica',10);y=h-45
        c.drawString(40,y,line[:150]);y-=13
    c.save();return output_path
