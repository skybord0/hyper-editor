from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A4
def txt_to_pdf(input_path,output_path):
    c=Canvas(output_path,pagesize=A4);w,h=A4;y=h-45;c.setFont('Helvetica',10)
    with open(input_path,encoding='utf-8',errors='replace') as f:lines=f.read().splitlines()
    for line in lines:
        if y<40:c.showPage();c.setFont('Helvetica',10);y=h-45
        c.drawString(40,y,line[:150]);y-=13
    c.save();return output_path
