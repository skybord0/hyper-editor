from docx import Document
def txt_to_word(input_path,output_path):
    d=Document()
    with open(input_path,encoding='utf-8',errors='replace') as f:
        for line in f.read().splitlines():d.add_paragraph(line)
    d.save(output_path);return output_path
