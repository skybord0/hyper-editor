import os,zipfile
def extract_zip(input_path,output_directory):
    os.makedirs(output_directory,exist_ok=True)
    with zipfile.ZipFile(input_path) as z:
        for i in z.infolist():
            n=os.path.normpath(i.filename)
            if n.startswith('..') or os.path.isabs(n):raise ValueError('Unsafe ZIP entry detected.')
        z.extractall(output_directory)
    return output_directory
