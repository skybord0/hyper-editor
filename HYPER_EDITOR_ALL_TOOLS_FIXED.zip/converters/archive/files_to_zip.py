import zipfile,os
def files_to_zip(input_paths,output_path):
    with zipfile.ZipFile(output_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in input_paths:z.write(p,os.path.basename(p))
    return output_path
