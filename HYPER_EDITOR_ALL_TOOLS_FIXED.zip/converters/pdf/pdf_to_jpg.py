import os,pymupdf
def convert_pdf_to_jpg(input_path,output_directory,dpi=150,quality=92):
    os.makedirs(output_directory,exist_ok=True);doc=pymupdf.open(input_path);files=[];scale=dpi/72
    try:
        for i,p in enumerate(doc):
            pix=p.get_pixmap(matrix=pymupdf.Matrix(scale,scale),alpha=False);name=f'{os.path.splitext(os.path.basename(input_path))[0]}_page_{i+1}.jpg';pix.save(os.path.join(output_directory,name),output='jpeg',jpg_quality=quality);files.append(name)
        return files
    finally:doc.close()
