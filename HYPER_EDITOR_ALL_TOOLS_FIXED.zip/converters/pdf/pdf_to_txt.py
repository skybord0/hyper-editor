import pymupdf
def convert_pdf_to_txt(input_path,output_path):
    doc=pymupdf.open(input_path)
    try:
        text='\n\n'.join(f'--- Page {i+1} ---\n\n{p.get_text("text").strip()}' for i,p in enumerate(doc))
        with open(output_path,'w',encoding='utf-8') as f:f.write(text)
    finally:doc.close()
    return output_path
