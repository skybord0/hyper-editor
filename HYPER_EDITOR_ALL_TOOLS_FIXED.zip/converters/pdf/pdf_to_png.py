import os,pymupdf
def convert_pdf_to_png(input_path,output_directory,dpi=150):
    os.makedirs(output_directory,exist_ok=True);doc=pymupdf.open(input_path);files=[];scale=dpi/72
    try:
        for i,p in enumerate(doc):
            pix=p.get_pixmap(matrix=pymupdf.Matrix(scale,scale),alpha=False);name=f'{os.path.splitext(os.path.basename(input_path))[0]}_page_{i+1}.png';pix.save(os.path.join(output_directory,name));files.append(name)
        return files
    finally:doc.close()
