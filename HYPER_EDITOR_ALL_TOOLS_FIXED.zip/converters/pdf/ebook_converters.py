import os, subprocess, shutil, zipfile, html, pymupdf

def pdf_to_epub(input_path, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc = pymupdf.open(input_path)
    pages = []
    try:
        for page in doc:
            pages.append(page.get_text('text'))
    finally:
        doc.close()
    manifest=[]; spine=[]
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype', 'application/epub+zip', compress_type=zipfile.ZIP_STORED)
        z.writestr('META-INF/container.xml', '''<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>''')
        for i, text in enumerate(pages, 1):
            fn=f'page{i}.xhtml'
            body=''.join('<p>'+html.escape(x)+'</p>' for x in text.splitlines() if x.strip())
            page=f'<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Page {i}</title></head><body>{body}</body></html>'
            z.writestr('OEBPS/'+fn, page)
            manifest.append(f'<item id="p{i}" href="{fn}" media-type="application/xhtml+xml"/>')
            spine.append(f'<itemref idref="p{i}"/>')
        opf='<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="BookId"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Converted PDF</dc:title><dc:identifier id="BookId">hyper-editor</dc:identifier><dc:language>en</dc:language></metadata><manifest>'+''.join(manifest)+'</manifest><spine>'+''.join(spine)+'</spine></package>'
        z.writestr('OEBPS/content.opf', opf)
    return output_path

def pdf_to_mobi(input_path, output_path):
    epub=output_path+'.epub'
    pdf_to_epub(input_path, epub)
    exe=shutil.which('ebook-convert')
    if not exe:
        try: os.remove(epub)
        except OSError: pass
        raise RuntimeError('MOBI conversion requires Calibre. Install Calibre and make ebook-convert available in PATH.')
    try:
        p=subprocess.run([exe, epub, output_path], capture_output=True, text=True, timeout=180)
        if p.returncode != 0 or not os.path.exists(output_path):
            raise RuntimeError(p.stderr or p.stdout or 'Calibre MOBI conversion failed.')
    finally:
        try: os.remove(epub)
        except OSError: pass
    return output_path
