import os,pymupdf
from openpyxl import Workbook
def convert_pdf_to_excel(input_path, output_path):
    wb=Workbook(); ws=wb.active; ws.title='PDF Content'; row=1
    try:
        import pdfplumber
        with pdfplumber.open(input_path) as p:
            for page in p.pages:
                tables=page.extract_tables() or []
                if tables:
                    for table in tables:
                        for vals in table:
                            for ci,v in enumerate(vals or [],1): ws.cell(row,ci,str(v or ''))
                            row+=1
                        row+=1
                else:
                    for line in (page.extract_text() or '').splitlines(): ws.cell(row,1,line); row+=1
    except Exception:
        doc=pymupdf.open(input_path)
        for page in doc:
            for line in page.get_text().splitlines(): ws.cell(row,1,line); row+=1
        doc.close()
    os.makedirs(os.path.dirname(output_path),exist_ok=True); wb.save(output_path); return output_path
