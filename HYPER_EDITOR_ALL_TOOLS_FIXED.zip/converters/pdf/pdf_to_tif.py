import os,pymupdf
from PIL import Image

def convert_pdf_to_tif(input_path,output_directory,dpi=150):
    os.makedirs(output_directory,exist_ok=True); doc=pymupdf.open(input_path); files=[]
    try:
        for i,p in enumerate(doc):
            pix=p.get_pixmap(matrix=pymupdf.Matrix(dpi/72,dpi/72),alpha=False)
            name=f'{os.path.splitext(os.path.basename(input_path))[0]}_page_{i+1}.tif'; path=os.path.join(output_directory,name)
            png_bytes=pix.tobytes('png')
            from io import BytesIO
            with Image.open(BytesIO(png_bytes)) as im: im.convert('RGB').save(path,'TIFF',compression='tiff_deflate')
            files.append(name)
        return files
    finally: doc.close()
