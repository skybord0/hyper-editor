import os,pymupdf,zipfile
def pdf_to_pages_zip(input_path,output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True); doc=pymupdf.open(input_path); tmp=output_path+'.tmp'; os.makedirs(tmp,exist_ok=True); names=[]
    try:
        for i in range(doc.page_count):
            one=pymupdf.open(); one.insert_pdf(doc,from_page=i,to_page=i); name=f'page_{i+1}.pdf'; path=os.path.join(tmp,name); one.save(path); one.close(); names.append(path)
        with zipfile.ZipFile(output_path,'w',zipfile.ZIP_DEFLATED) as z:
            for p in names:z.write(p,os.path.basename(p))
    finally:
        doc.close()
        for p in names:
            try: os.remove(p)
            except OSError: pass
        try: os.rmdir(tmp)
        except OSError: pass
    return output_path
