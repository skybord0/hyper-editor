import os,pymupdf

def split_pdf(input_path,output_dir,pages_per_file=1,page_spec=None):
    os.makedirs(output_dir,exist_ok=True);doc=pymupdf.open(input_path);files=[]
    try:
        if page_spec:
            indexes=[]
            for part in str(page_spec).split(','):
                part=part.strip()
                if '-' in part:
                    a,b=map(int,part.split('-',1));indexes.extend(range(min(a,b)-1,max(a,b)))
                elif part.isdigit():indexes.append(int(part)-1)
            indexes=sorted(set(i for i in indexes if 0<=i<doc.page_count))
        else:indexes=list(range(doc.page_count))
        step=max(1,int(pages_per_file))
        for start in range(0,len(indexes),step):
            out=pymupdf.open()
            for i in indexes[start:start+step]:out.insert_pdf(doc,from_page=i,to_page=i)
            name=f'split_{start//step+1}.pdf';out.save(os.path.join(output_dir,name));out.close();files.append(name)
        return files
    finally:doc.close()
