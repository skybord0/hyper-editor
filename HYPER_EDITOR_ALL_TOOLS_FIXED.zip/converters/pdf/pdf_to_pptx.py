import os,pymupdf
from pptx import Presentation
from pptx.util import Inches
def convert_pdf_to_pptx(input_path, output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    doc=pymupdf.open(input_path); prs=Presentation(); prs.slide_width=Inches(13.333); prs.slide_height=Inches(7.5); blank=prs.slide_layouts[6]
    for i,page in enumerate(doc):
        pix=page.get_pixmap(matrix=pymupdf.Matrix(2,2),alpha=False); tmp=os.path.join(os.path.dirname(output_path),f'.pdfslide_{os.getpid()}_{i}.png'); pix.save(tmp)
        slide=prs.slides.add_slide(blank); slide.shapes.add_picture(tmp,0,0,width=prs.slide_width,height=prs.slide_height); os.remove(tmp)
    doc.close(); prs.save(output_path); return output_path
