import os

def _pdf2docx(input_path, output_path):
    try:
        from pdf2docx import Converter
    except Exception:
        return False
    cv = Converter(input_path)
    try:
        cv.convert(output_path, start=0, end=None)
        return True
    finally:
        cv.close()

def convert_pdf_to_word(input_path, output_path):
    """
    Reconstruct a PDF as an editable DOCX.
    pdf2docx is the primary engine because it handles page geometry,
    paragraphs, tables, images, fonts and spacing much better than a
    hand-written text extraction routine.
    """
    if _pdf2docx(input_path, output_path):
        return output_path

    # Fallback keeps PDF page dimensions and every text span's basic style.
    # It is intentionally conservative rather than pretending to be pixel-perfect.
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    import pymupdf

    pdf = pymupdf.open(input_path)
    out = Document()
    try:
        for i, page in enumerate(pdf):
            if i:
                out.add_page_break()
            sec = out.sections[-1]
            sec.page_width = Inches(page.rect.width / 72.0)
            sec.page_height = Inches(page.rect.height / 72.0)
            sec.top_margin = Inches(0)
            sec.bottom_margin = Inches(0)
            sec.left_margin = Inches(0)
            sec.right_margin = Inches(0)

            for block in page.get_text("dict").get("blocks", []):
                if block.get("type") != 0:
                    continue
                for line in block.get("lines", []):
                    para = out.add_paragraph()
                    para.paragraph_format.space_before = Pt(0)
                    para.paragraph_format.space_after = Pt(0)
                    para.paragraph_format.line_spacing = 1
                    for span in line.get("spans", []):
                        text = span.get("text", "")
                        if not text:
                            continue
                        run = para.add_run(text)
                        run.font.size = Pt(float(span.get("size", 10)))
                        flags = int(span.get("flags", 0))
                        run.bold = bool(flags & 16)
                        run.italic = bool(flags & 2)
                        c = int(span.get("color", 0))
                        run.font.color.rgb = RGBColor(
                            (c >> 16) & 255, (c >> 8) & 255, c & 255
                        )
        out.save(output_path)
    finally:
        pdf.close()
    return output_path
