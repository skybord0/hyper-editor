import pymupdf
def merge_pdf_files(input_paths,output_path):
    if len(input_paths)<2:raise ValueError('At least two PDF files are required to merge.')
    out=pymupdf.open()
    try:
        for p in input_paths:
            src=pymupdf.open(p);out.insert_pdf(src);src.close()
        out.save(output_path)
    finally:out.close()
    return output_path
