import pymupdf

def compress_pdf(input_path, output_path, level='balanced'):
    doc=pymupdf.open(input_path)
    try: doc.save(output_path,garbage=4,clean=True,deflate=True,deflate_images=True,deflate_fonts=True,use_objstms=True)
    finally: doc.close()
    return output_path
