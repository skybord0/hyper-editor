import os,shutil,subprocess

def convert_pptx_to_pdf(input_path,output_path):
    soffice=shutil.which('soffice') or shutil.which('libreoffice')
    if soffice:
        outdir=os.path.dirname(os.path.abspath(output_path)); os.makedirs(outdir,exist_ok=True)
        p=subprocess.run([soffice,'--headless','--convert-to','pdf','--outdir',outdir,input_path],capture_output=True,text=True,timeout=180)
        produced=os.path.join(outdir,os.path.splitext(os.path.basename(input_path))[0]+'.pdf')
        if p.returncode==0 and os.path.exists(produced):
            if os.path.abspath(produced)!=os.path.abspath(output_path):
                if os.path.exists(output_path): os.remove(output_path)
                os.replace(produced,output_path)
            return output_path
    raise RuntimeError('PPTX to PDF requires LibreOffice for reliable slide rendering. Install LibreOffice and try again.')
