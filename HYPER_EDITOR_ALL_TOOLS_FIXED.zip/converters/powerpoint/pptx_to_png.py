import os,tempfile
from converters.powerpoint.pptx_to_pdf import convert_pptx_to_pdf
from converters.pdf.pdf_to_png import convert_pdf_to_png
def convert_pptx_to_png(input_path,output_directory):
    os.makedirs(output_directory,exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        p=os.path.join(d,'slides.pdf');convert_pptx_to_pdf(input_path,p);return convert_pdf_to_png(p,output_directory)
