import os,shutil,subprocess

def convert_xlsx_to_pdf(input_path,output_path):
    soffice=shutil.which('soffice') or shutil.which('libreoffice')
    if soffice:
        outdir=os.path.dirname(os.path.abspath(output_path)); os.makedirs(outdir,exist_ok=True)
        p=subprocess.run([soffice,'--headless','--convert-to','pdf','--outdir',outdir,input_path],capture_output=True,text=True,timeout=180)
        produced=os.path.join(outdir,os.path.splitext(os.path.basename(input_path))[0]+'.pdf')
        if p.returncode==0 and os.path.exists(produced):
            if os.path.abspath(produced)!=os.path.abspath(output_path):
                if os.path.exists(output_path): os.remove(output_path)
                os.replace(produced,output_path)
            return output_path
    from openpyxl import load_workbook
    from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
    from reportlab.lib.pagesizes import landscape,A4
    from reportlab.lib import colors
    wb=load_workbook(input_path,data_only=True); story=[]
    for ws in wb.worksheets:
        data=[[str(c.value or '') for c in row] for row in ws.iter_rows()]
        if data:
            t=Table(data,repeatRows=1); t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.4,colors.grey)])); story += [Paragraph(ws.title),t,Spacer(1,12)]
    SimpleDocTemplate(output_path,pagesize=landscape(A4),leftMargin=24,rightMargin=24,topMargin=24,bottomMargin=24).build(story)
    return output_path
