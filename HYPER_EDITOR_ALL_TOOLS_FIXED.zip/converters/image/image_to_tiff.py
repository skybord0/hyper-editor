from PIL import Image
import os
def convert_image_to_tiff(input_path, output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    with Image.open(input_path) as im:
        if im.mode not in ('RGB','L'): im=im.convert('RGB')
        im.save(output_path,'TIFF',compression='tiff_deflate')
    return output_path
