import os

from PIL import Image


def convert_images_to_pdf(
    input_paths,
    output_path
):
    """
    Convert one or more PNG/JPG/JPEG images
    into a single PDF file.

    Each image becomes one PDF page.
    """

    if not input_paths:
        raise ValueError(
            "No images were provided."
        )

    for input_path in input_paths:

        if not os.path.isfile(input_path):
            raise FileNotFoundError(
                f"Image file was not found: {input_path}"
            )

    output_directory = os.path.dirname(
        output_path
    )

    if output_directory:
        os.makedirs(
            output_directory,
            exist_ok=True
        )

    converted_images = []

    try:

        for input_path in input_paths:

            with Image.open(input_path) as image:

                if image.mode in (
                    "RGBA",
                    "LA",
                    "P"
                ):

                    if image.mode == "P":
                        image = image.convert(
                            "RGBA"
                        )

                    if image.mode in (
                        "RGBA",
                        "LA"
                    ):

                        background = Image.new(
                            "RGB",
                            image.size,
                            "white"
                        )

                        alpha = image.getchannel(
                            "A"
                        )

                        background.paste(
                            image,
                            mask=alpha
                        )

                        converted_image = background

                    else:

                        converted_image = image.convert(
                            "RGB"
                        )

                else:

                    converted_image = image.convert(
                        "RGB"
                    )

                converted_images.append(
                    converted_image.copy()
                )

        first_image = converted_images[0]

        remaining_images = converted_images[1:]

        first_image.save(
            output_path,
            format="PDF",
            resolution=150.0,
            save_all=True,
            append_images=remaining_images
        )

    finally:

        for image in converted_images:

            try:
                image.close()
            except Exception:
                pass

    return output_path