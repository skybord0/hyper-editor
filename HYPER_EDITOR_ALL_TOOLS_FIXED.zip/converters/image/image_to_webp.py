import os

from PIL import Image


def convert_image_to_webp(input_path, output_path):
    """
    Convert a PNG/JPG/JPEG image to WEBP format.
    """

    if not os.path.isfile(input_path):
        raise FileNotFoundError(
            "Input image file was not found."
        )

    output_directory = os.path.dirname(output_path)

    if output_directory:
        os.makedirs(
            output_directory,
            exist_ok=True
        )

    with Image.open(input_path) as image:

        # Keep transparency when the source image supports it.
        if image.mode in ("RGBA", "LA"):
            converted_image = image.convert("RGBA")
        else:
            converted_image = image.convert("RGB")

        converted_image.save(
            output_path,
            format="WEBP",
            quality=95,
            method=6
        )

    return output_path