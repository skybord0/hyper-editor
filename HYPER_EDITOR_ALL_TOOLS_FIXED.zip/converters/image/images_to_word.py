import os

from PIL import Image
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches


def convert_images_to_word(
    input_paths,
    output_path
):
    """
    Convert one or more PNG/JPG/JPEG images
    into a single Word DOCX document.

    Each image is placed on its own page.
    """

    if not input_paths:
        raise ValueError(
            "No images were provided."
        )

    for input_path in input_paths:
        if not os.path.isfile(input_path):
            raise FileNotFoundError(
                f"Image file was not found: {input_path}"
            )

    output_directory = os.path.dirname(
        output_path
    )

    if output_directory:
        os.makedirs(
            output_directory,
            exist_ok=True
        )

    document = Document()

    section = document.sections[0]

    section.top_margin = Inches(0.5)
    section.bottom_margin = Inches(0.5)
    section.left_margin = Inches(0.5)
    section.right_margin = Inches(0.5)

    for index, input_path in enumerate(input_paths):

        with Image.open(input_path) as image:

            image_width, image_height = image.size

        if image_width <= 0 or image_height <= 0:
            raise ValueError(
                f"Invalid image dimensions: {input_path}"
            )

        # Available page area after margins.
        page_width = (
            section.page_width
            - section.left_margin
            - section.right_margin
        )

        page_height = (
            section.page_height
            - section.top_margin
            - section.bottom_margin
        )

        # Convert EMU values to inches.
        available_width = (
            page_width / 914400
        )

        available_height = (
            page_height / 914400
        )

        # Preserve the original aspect ratio.
        image_ratio = (
            image_width / image_height
        )

        if (
            available_width
            / available_height
        ) < image_ratio:

            display_width = available_width
            display_height = (
                display_width
                / image_ratio
            )

        else:

            display_height = available_height
            display_width = (
                display_height
                * image_ratio
            )

        paragraph = document.add_paragraph()

        paragraph.alignment = (
            WD_ALIGN_PARAGRAPH.CENTER
        )

        paragraph.add_run().add_picture(
            input_path,
            width=Inches(display_width),
            height=Inches(display_height)
        )

        # Put every image on its own page.
        if index < len(input_paths) - 1:
            document.add_page_break()

    document.save(output_path)

    return output_path