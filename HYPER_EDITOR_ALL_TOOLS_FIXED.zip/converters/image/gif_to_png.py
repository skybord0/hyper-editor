from PIL import Image
import os
def convert_gif_to_png(input_path, output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    with Image.open(input_path) as im: im.convert('RGBA').save(output_path,'PNG')
    return output_path
