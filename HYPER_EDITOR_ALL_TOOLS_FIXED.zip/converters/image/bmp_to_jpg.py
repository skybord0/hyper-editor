from PIL import Image
import os
def convert_bmp_to_jpg(input_path, output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    with Image.open(input_path) as im: im.convert('RGB').save(output_path,'JPEG',quality=95,optimize=True)
    return output_path
