import os
def convert_heic_to_jpg(input_path, output_path):
    try:
        from pillow_heif import register_heif_opener
        register_heif_opener()
        from PIL import Image
    except Exception as e:
        raise RuntimeError('HEIC support requires pillow-heif. Run pip install -r requirements.txt.') from e
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    with Image.open(input_path) as im: im.convert('RGB').save(output_path,'JPEG',quality=95)
    return output_path
