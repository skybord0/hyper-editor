from PIL import Image
import os
def convert_image_to_bmp(input_path, output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    with Image.open(input_path) as im: im.convert('RGB').save(output_path,'BMP')
    return output_path
