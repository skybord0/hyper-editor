from PIL import Image
import os
def convert_image_to_gif(input_path, output_path):
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    with Image.open(input_path) as im: im.convert('RGBA').save(output_path,'GIF')
    return output_path
def make_gif(input_paths, output_path, duration=350, loop=0):
    if not input_paths: raise ValueError('At least one image is required.')
    frames=[]
    for p in input_paths:
        with Image.open(p) as im: frames.append(im.convert('RGBA').copy())
    os.makedirs(os.path.dirname(output_path),exist_ok=True)
    frames[0].save(output_path,'GIF',save_all=True,append_images=frames[1:],duration=duration,loop=loop,disposal=2)
    return output_path
