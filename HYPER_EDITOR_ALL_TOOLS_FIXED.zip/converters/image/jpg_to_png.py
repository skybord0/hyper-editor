import os

from PIL import Image


def convert_jpg_to_png(input_path, output_path):
    """
    Convert a JPG/JPEG image to PNG format.
    """

    if not os.path.isfile(input_path):
        raise FileNotFoundError("Input JPG file was not found.")

    output_directory = os.path.dirname(output_path)

    if output_directory:
        os.makedirs(output_directory, exist_ok=True)

    with Image.open(input_path) as image:
        image = image.convert("RGB")

        image.save(
            output_path,
            format="PNG",
            optimize=True
        )

    return output_path