import os
from PIL import Image


def convert_png_to_jpg(input_path, output_path):
    """
    Convert a PNG image to JPG format.

    PNG images may contain transparency, so the image is
    converted to RGB before saving as JPEG.
    """

    if not os.path.isfile(input_path):
        raise FileNotFoundError("Input PNG file was not found.")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    with Image.open(input_path) as image:
        if image.mode in ("RGBA", "LA", "P"):
            background = Image.new("RGB", image.size, "white")

            if image.mode == "P":
                image = image.convert("RGBA")

            if image.mode in ("RGBA", "LA"):
                background.paste(
                    image,
                    mask=image.getchannel("A")
                )
            else:
                background.paste(image)

            image = background
        else:
            image = image.convert("RGB")

        image.save(
            output_path,
            format="JPEG",
            quality=95,
            optimize=True
        )

    return output_path